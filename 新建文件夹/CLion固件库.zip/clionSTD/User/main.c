#include "stm32f10x.h" 

int main(void) {
	while(1) {
		// project begin
	}
}
